# Zepto Assignment — Project Repository

## Module 1 — Data Pipeline (`/data_pipeline`)

See [`data_pipeline/README.md`](data_pipeline/README.md) for full details: scraping
books.toscrape.com, cleaning, GBP->INR conversion at the fixed baseline rate
(1 GBP = 105.50 INR), a normalized two-table SQLite schema, 5+ SQL queries covering
SELECT/WHERE, ORDER BY/LIMIT, DISTINCT, BETWEEN/IN, and a JOIN, plus a
pd.read_sql vs pd.merge equivalence check.

Repo history: work was done on `feature/data-pipeline` (3 commits) and merged into `main`.

## Module 2 — Analytics Pipeline (`/analytics`)

See [`analytics/README.md`](analytics/README.md) for full details: Titanic EDA (missing-value
handling, univariate/bivariate/multivariate analysis with a 5-chart data story), a stratified
train/test split, a ColumnTransformer+Pipeline preprocessing setup, three trained classifiers
(Logistic Regression / Decision Tree / Random Forest) with full metric suites and ROC/AUC,
a 3-way imbalance-handling comparison (baseline vs class_weight vs SMOTE), GridSearchCV
hyperparameter tuning with OOB score, a fare-prediction regression side-task, and a saved,
reloadable end-to-end joblib pipeline.
