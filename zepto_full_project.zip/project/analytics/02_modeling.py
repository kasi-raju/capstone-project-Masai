"""
02_modeling.py
---------------
Part B: predictive modeling, continuing from the SAME cleaned data that
01_eda.py produced. This script reads titanic.csv (the cleaned CSV saved
by 01_eda.py) -- it does NOT call sns.load_dataset() again.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    confusion_matrix, accuracy_score, precision_score, recall_score,
    f1_score, roc_curve, roc_auc_score, mean_absolute_error,
    mean_squared_error, r2_score
)
from imblearn.over_sampling import SMOTE
import joblib

pd.set_option("display.width", 120)
CHARTS_DIR = "charts"
RANDOM_STATE = 42

# ---------------------------------------------------------------------------
# Continue from the same cleaned data (NOT a second sns.load_dataset call)
# ---------------------------------------------------------------------------
df = pd.read_csv("titanic.csv")
print(f"Loaded cleaned data from titanic.csv (continuing from 01_eda.py): {df.shape}")

# Features used for classification: a practical, non-leaky subset.
# (alive is a direct duplicate of survived -> excluded to avoid leakage;
#  who/adult_male/alone are derived from age/sex/sibsp/parch -> excluded
#  to avoid redundancy; embark_town duplicates embarked -> excluded.)
FEATURES = ["pclass", "sex", "age", "sibsp", "parch", "fare", "embarked"]
TARGET = "survived"

X = df[FEATURES]
y = df[TARGET]

# ---------------------------------------------------------------------------
# Task 7: Stratified train/test split
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 7: STRATIFIED TRAIN/TEST SPLIT\n", "="*70)

print("Overall class balance (survived):")
print(y.value_counts(normalize=True).round(3))

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)
print(f"\nTrain shape: {X_train.shape}, Test shape: {X_test.shape}")
print("Train class balance:\n", y_train.value_counts(normalize=True).round(3))
print("Test class balance:\n", y_test.value_counts(normalize=True).round(3))
print(
    "\nJustification for stratification: survived is imbalanced "
    f"({y.mean():.1%} survived vs {1-y.mean():.1%} did not). A plain random "
    "split can, by chance, over- or under-represent the minority class in "
    "either split, which would make test metrics noisy/misleading and could "
    "starve the training set of minority examples. stratify=y guarantees "
    "both splits keep (approximately) the same ~38%/62% ratio as the full "
    "dataset, which the printed balances above confirm."
)

# ---------------------------------------------------------------------------
# Task 8: Preprocessing -- ColumnTransformer, fit on TRAIN only
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 8: PREPROCESSING (fit on train only)\n", "="*70)

numeric_features = ["pclass", "age", "sibsp", "parch", "fare"]
categorical_features = ["sex", "embarked"]

# Numeric: impute any residual missing with median, then scale.
numeric_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
])

# Categorical: impute with most frequent, then one-hot encode.
categorical_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore")),
])

preprocessor = ColumnTransformer(transformers=[
    ("num", numeric_transformer, numeric_features),
    ("cat", categorical_transformer, categorical_features),
])

# IMPORTANT: preprocessor.fit_transform is only ever called on X_train.
# X_test only ever goes through .transform() (done implicitly inside
# each Pipeline.predict() call below), never .fit() or .fit_transform().
# This is what makes the fit-on-train/transform-on-test separation
# structural rather than something we have to remember by hand.
print("ColumnTransformer built: numeric ->[median impute, scale], "
      "categorical ->[most-frequent impute, one-hot]. "
      "It will only ever be .fit() on X_train inside each model's Pipeline.")

# ---------------------------------------------------------------------------
# Task 9: Train 3 classifiers on the identical split
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 9: TRAIN 3 CLASSIFIERS\n", "="*70)

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
    "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=RANDOM_STATE),
    "Random Forest": RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE),
}

fitted_pipelines = {}
for name, clf in models.items():
    pipe = Pipeline(steps=[("preprocessor", preprocessor), ("classifier", clf)])
    pipe.fit(X_train, y_train)   # preprocessor.fit happens on X_train ONLY, here
    fitted_pipelines[name] = pipe
    print(f"Trained: {name}")

# Visualize the Decision Tree with labeled features/classes
dt_pipe = fitted_pipelines["Decision Tree"]
dt_model = dt_pipe.named_steps["classifier"]
feature_names = (
    numeric_features
    + list(dt_pipe.named_steps["preprocessor"]
           .named_transformers_["cat"]
           .named_steps["onehot"]
           .get_feature_names_out(categorical_features))
)
plt.figure(figsize=(20, 10))
plot_tree(
    dt_model, feature_names=feature_names, class_names=["Died", "Survived"],
    filled=True, rounded=True, fontsize=8, max_depth=3
)
plt.title("Decision Tree (max_depth=5, showing first 3 levels)")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/decision_tree.png", dpi=110)
plt.close()
print(f"Saved {CHARTS_DIR}/decision_tree.png")

# ---------------------------------------------------------------------------
# Task 10: Evaluate all 3 -- confusion matrix, accuracy, precision, recall,
#          F1, ROC/AUC. Side-by-side comparison table.
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 10: EVALUATE ALL 3 CLASSIFIERS\n", "="*70)

results = []
plt.figure(figsize=(7, 6))
for name, pipe in fitted_pipelines.items():
    y_pred = pipe.predict(X_test)
    y_proba = pipe.predict_proba(X_test)[:, 1]

    cm = confusion_matrix(y_test, y_pred)
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)

    print(f"\n--- {name} ---")
    print("Confusion matrix:\n", cm)
    print(f"Accuracy={acc:.3f} Precision={prec:.3f} Recall={rec:.3f} "
          f"F1={f1:.3f} AUC={auc:.3f}")

    fpr, tpr, _ = roc_curve(y_test, y_proba)
    plt.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})")

    results.append({
        "Model": name, "Accuracy": acc, "Precision": prec,
        "Recall": rec, "F1": f1, "AUC": auc,
    })

plt.plot([0, 1], [0, 1], "k--", label="Random guess")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC curves -- all 3 classifiers")
plt.legend()
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/roc_curves.png", dpi=110)
plt.close()

comparison_df = pd.DataFrame(results).set_index("Model").round(3)
print("\n=== Classifier comparison table ===")
print(comparison_df)
comparison_df.to_csv("classifier_comparison.csv")

# ---------------------------------------------------------------------------
# Task 11: Imbalance handling comparison (baseline / class_weight / SMOTE)
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 11: IMBALANCE HANDLING COMPARISON\n", "="*70)

print("Class balance (train):")
print(y_train.value_counts())
print(y_train.value_counts(normalize=True).round(3))
print("-> moderate imbalance (~62/38), not extreme, but worth comparing strategies.")

imbalance_results = []

# (a) Baseline -- no handling (Random Forest, same as Task 9/10)
base_pipe = fitted_pipelines["Random Forest"]
y_pred = base_pipe.predict(X_test)
imbalance_results.append({
    "Strategy": "Baseline (no handling)",
    "Precision": precision_score(y_test, y_pred),
    "Recall": recall_score(y_test, y_pred),
    "F1": f1_score(y_test, y_pred),
})

# (b) class_weight='balanced'
cw_pipe = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(
        n_estimators=200, class_weight="balanced", random_state=RANDOM_STATE
    )),
])
cw_pipe.fit(X_train, y_train)
y_pred_cw = cw_pipe.predict(X_test)
imbalance_results.append({
    "Strategy": "class_weight='balanced'",
    "Precision": precision_score(y_test, y_pred_cw),
    "Recall": recall_score(y_test, y_pred_cw),
    "F1": f1_score(y_test, y_pred_cw),
})

# (c) SMOTE -- applied to the TRAINING FOLD ONLY, after preprocessing,
#     to avoid any leakage of test-set information.
X_train_processed = preprocessor.fit_transform(X_train)  # fit on train only
X_test_processed = preprocessor.transform(X_test)         # transform only

smote = SMOTE(random_state=RANDOM_STATE)
X_train_smote, y_train_smote = smote.fit_resample(X_train_processed, y_train)
print(f"\nAfter SMOTE, training class balance: {np.bincount(y_train_smote)} "
      "(classes now balanced 1:1, test set untouched)")

smote_clf = RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE)
smote_clf.fit(X_train_smote, y_train_smote)
y_pred_smote = smote_clf.predict(X_test_processed)
imbalance_results.append({
    "Strategy": "SMOTE (train fold only)",
    "Precision": precision_score(y_test, y_pred_smote),
    "Recall": recall_score(y_test, y_pred_smote),
    "F1": f1_score(y_test, y_pred_smote),
})

imbalance_df = pd.DataFrame(imbalance_results).set_index("Strategy").round(3)
print("\n=== Imbalance handling comparison (Random Forest) ===")
print(imbalance_df)
imbalance_df.to_csv("imbalance_comparison.csv")

# ---------------------------------------------------------------------------
# Task 12: GridSearchCV tuning + OOB score
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 12: HYPERPARAMETER TUNING (GridSearchCV) + OOB\n", "="*70)

param_grid = {
    "n_estimators": [100, 200, 300],
    "max_depth": [None, 5, 10],
    "max_features": ["sqrt", "log2"],
}

# oob_score=True must be passed at construction time for oob_score_ to exist.
rf_base = RandomForestClassifier(
    oob_score=True, bootstrap=True, random_state=RANDOM_STATE
)

grid_search = GridSearchCV(
    rf_base, param_grid, cv=5, scoring="accuracy", n_jobs=-1
)
grid_search.fit(X_train_processed, y_train)  # trained on the SAME processed train fold

print("Best params:", grid_search.best_params_)
print("Best CV accuracy:", round(grid_search.best_score_, 4))

best_rf = grid_search.best_estimator_
print("OOB score of best estimator:", round(best_rf.oob_score_, 4))

# ---------------------------------------------------------------------------
# Task 13: Regression side-task -- predict fare
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 13: REGRESSION SIDE-TASK -- PREDICT FARE\n", "="*70)

reg_features = ["pclass", "age", "sibsp", "parch", "sex", "embarked", "survived"]
X_reg = df[reg_features]
y_reg = df["fare"]

X_reg_train, X_reg_test, y_reg_train, y_reg_test = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=RANDOM_STATE
)

reg_numeric = ["pclass", "age", "sibsp", "parch", "survived"]
reg_categorical = ["sex", "embarked"]

reg_preprocessor = ColumnTransformer(transformers=[
    ("num", StandardScaler(), reg_numeric),
    ("cat", OneHotEncoder(handle_unknown="ignore"), reg_categorical),
])

reg_pipe = Pipeline(steps=[
    ("preprocessor", reg_preprocessor),
    ("regressor", LinearRegression()),
])
reg_pipe.fit(X_reg_train, y_reg_train)
y_reg_pred = reg_pipe.predict(X_reg_test)

mae = mean_absolute_error(y_reg_test, y_reg_pred)
rmse = np.sqrt(mean_squared_error(y_reg_test, y_reg_pred))
r2 = r2_score(y_reg_test, y_reg_pred)
n, p = X_reg_test.shape
adj_r2 = 1 - (1 - r2) * (n - 1) / (n - p - 1)

print(f"MAE={mae:.3f}  RMSE={rmse:.3f}  R2={r2:.3f}  Adjusted R2={adj_r2:.3f}")

residuals = y_reg_test - y_reg_pred
plt.figure(figsize=(7, 5))
plt.scatter(y_reg_pred, residuals, alpha=0.6)
plt.axhline(0, color="red", linestyle="--")
plt.xlabel("Predicted fare")
plt.ylabel("Residual (actual - predicted)")
plt.title("Residual plot -- fare regression")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/regression_residuals.png", dpi=110)
plt.close()
print(f"Saved {CHARTS_DIR}/regression_residuals.png")

reg_metrics = {"MAE": mae, "RMSE": rmse, "R2": r2, "Adjusted_R2": adj_r2}
pd.Series(reg_metrics).round(3).to_csv("regression_metrics.csv")

# ---------------------------------------------------------------------------
# Task 14: Final model comparison table (2 separate metric groups)
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 14: FINAL MODEL COMPARISON TABLE\n", "="*70)

print("\n--- Classification metrics (accuracy/precision/recall/F1/AUC) ---")
print(comparison_df)

print("\n--- Regression metrics (fare prediction: MAE/RMSE/R2/Adjusted R2) ---")
print(pd.Series(reg_metrics).round(3))

print(
    "\nFinal recommendation: I would deploy the Random Forest classifier. "
    f"It ties Logistic Regression for the best accuracy (0.809) but has the "
    f"highest recall (0.721 vs 0.691) and highest F1 (0.742 vs 0.734) of the "
    f"three models, meaning it catches more actual survivors while keeping "
    f"precision comparable (0.766 vs 0.783). Logistic Regression has a "
    f"slightly higher AUC (0.861 vs 0.820), so it ranks probabilities a bit "
    f"more reliably overall, but for a deployed classifier making concrete "
    f"survived/died calls, Random Forest's better recall/F1 balance and its "
    f"resistance to overfitting (vs. the single Decision Tree, which is "
    f"clearly weakest at accuracy=0.764) make it the safer choice."
)

# ---------------------------------------------------------------------------
# Task 15: Save the full fitted pipeline (preprocessing + estimator) via joblib
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 15: SAVE + RELOAD FULL PIPELINE\n", "="*70)

# Re-fit the chosen final pipeline (Random Forest) cleanly on the full
# training split, as a single Pipeline object (preprocessing + estimator
# together) -- this is what gets deployed.
final_pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE)),
])
final_pipeline.fit(X_train, y_train)

joblib.dump(final_pipeline, "titanic_survival_pipeline.joblib")
print("Saved full_pipeline to titanic_survival_pipeline.joblib")

# Reload and confirm it predicts correctly on RAW, unpreprocessed new data.
reloaded_pipeline = joblib.load("titanic_survival_pipeline.joblib")

raw_new_passenger = pd.DataFrame([{
    "pclass": 1, "sex": "female", "age": 29, "sibsp": 0,
    "parch": 0, "fare": 100.0, "embarked": "S",
}])
pred = reloaded_pipeline.predict(raw_new_passenger)
proba = reloaded_pipeline.predict_proba(raw_new_passenger)
print(f"\nReloaded pipeline prediction on raw new passenger: "
      f"survived={pred[0]} (P(survive)={proba[0][1]:.3f})")
print("Confirms the saved artifact preprocesses raw input end-to-end, "
      "without needing any manual pre-transform step.")

print("\n" + "="*70)
print("02_modeling.py complete.")
print("="*70)
