# Module 2 — Analytics Pipeline

One cohesive pipeline on the Titanic dataset: `01_eda.py` loads (via `sns.load_dataset`,
exactly once), profiles, cleans, and explores the data, saving `titanic.csv`.
`02_modeling.py` reads that same `titanic.csv` and continues straight into modeling —
it never reloads from the network.

## How to run

```bash
pip install seaborn pandas numpy scikit-learn imbalanced-learn matplotlib joblib
python 01_eda.py        # -> titanic.csv, charts/*.png
python 02_modeling.py   # -> classifier_comparison.csv, imbalance_comparison.csv,
                         #    regression_metrics.csv, titanic_survival_pipeline.joblib
```

If `sns.load_dataset` can't reach the network at grading time, `01_eda.py`'s
`sns.load_dataset(...)` call is the only place that matters — `titanic.csv` is already
committed, so `02_modeling.py` (and any re-run of the cleaning steps) works from
`pd.read_csv("titanic.csv")` regardless.

---

## Part A — Profiling, cleaning, and the data story

### Missing values (Task 1–2)

| Column | % missing | Rule band | Action |
|---|---|---|---|
| `deck` | 77.22% | very high (> 30%, unreliable to impute) | **Dropped the column.** Imputing a deck for 4 out of 5 passengers would fabricate information; `pclass`/`class` (fully populated) captures similar "where on the ship" signal. |
| `age` | 19.87% | 5%–30% | **Imputed with median** (28.0). Median is robust to `age`'s right skew (a few elderly passengers would drag a mean-imputation upward). |
| `embarked` | 0.22% | < 5% | **Dropped rows** (2 rows). |
| `embark_town` | 0.22% | < 5% | **Dropped rows** (same 2 rows, dropped together with `embarked`). |

Shape after cleaning: **889 rows × 14 columns** (from 891 × 15), zero missing values remaining.

### Univariate analysis (Task 3)

See `charts/univariate_age_fare.png`.

- **age**: IQR = [22.00, 35.00], bounds = [2.50, 54.50] → **65 outliers** (mostly older passengers above ~54.5; the median-imputation spike is visible as the tall bar around 28).
- **fare**: IQR = [7.90, 31.00], bounds = [-26.76, 65.66] → **114 outliers**, all on the high end (fares above ~£65.66, up to £512).
- **fare** mean=32.10, median=14.45, mode=8.05. Since **mean > median > mode**, fare is clearly **right-skewed**: a small number of very expensive first-class fares pull the mean well above the typical (median) fare.

### Bivariate analysis (Task 4)

- **By sex**: male survival rate **0.189**, female survival rate **0.740** — women were roughly 4x more likely to survive than men.
- **By pclass**: 1st = **0.626**, 2nd = **0.473**, 3rd = **0.242** — survival drops steadily as class drops.
- **By sex + pclass**: 1st-class women survived at **0.967**, 2nd-class women at **0.921**, but 3rd-class women only **0.500** — class mattered enormously even within the same sex. Men's rates were far lower throughout (1st: 0.369, 2nd: 0.157, 3rd: 0.135), showing "women and children first" applied much more strongly than class alone would predict.

**Correlation matrix** (`survived, pclass, age, sibsp, parch, fare`) — see `charts/correlation_heatmap.png`.

Two strongest off-diagonal correlations (by |r|):
1. **pclass ↔ fare: r = -0.548** — makes sense structurally: `pclass` is coded 1 (best) to 3 (worst), so a strong *negative* correlation with fare means better (lower-numbered) classes paid more, exactly as expected.
2. **sibsp ↔ parch: r = 0.415** — passengers traveling with siblings/spouses also tended to travel with parents/children, i.e. family groups tend to have both types of relatives aboard together rather than just one.

### Multivariate data story (Task 5)

Five charts in `charts/` (4 required + 1 bonus pairplot):

1. **`story_1_survival_by_class_sex.png`** — Survival rate by class and sex side by side. Women's survival rate stays high (>0.9) in 1st/2nd class and only drops to ~0.5 in 3rd; men's rate is low everywhere but highest in 1st class (~0.37). This shows sex was the dominant factor, with class acting as a strong secondary modifier — especially for women.
2. **`story_2_age_by_survival.png`** — Age distribution split by survival outcome. The two boxes are very similar in median (median-imputation compressed a lot of the natural variation), but survivors show a slightly narrower spread with the outlier ages skewing toward non-survivors. Age alone is a weaker signal here than sex or class, matching its near-zero correlation with `survived` (r=-0.070) in the correlation matrix.
3. **`story_3_fare_age_scatter.png`** — Fare vs. age scatter, colored by survival. Survivors (orange) are visibly denser at higher fares, while low-fare passengers skew toward non-survival (blue) — fare acts as a rough proxy for class/wealth, reinforcing the class-based pattern from chart 1.
4. **`story_4_survival_by_family_size.png`** — Survival rate by family size (`sibsp+parch`). Solo travelers (family_size=0) survived at only ~0.30, small families (1-3) survived at 0.55-0.72, and very large families (4+) dropped back down toward 0.15-0.35. This is a "sweet spot" pattern: traveling entirely alone or in a very large group each carried a survival penalty compared to a small family.
5. **`story_5_pairplot.png`** (bonus) — Pairwise relationships between `survived`, `age`, `fare`, `pclass`, confirming visually that `fare` and `pclass` separate survivors/non-survivors more cleanly than `age` does.

### Standardization sanity check (Task 6)

Before: `age` mean=29.315, std=12.985; `fare` mean=32.097, std=49.698.
After z-scoring: both `age_z` and `fare_z` have **mean ≈ 0.000, std ≈ 1.000** — confirms the transform behaves as expected. This is an EDA-only check; the modeling pipeline below fits its own `StandardScaler` on the training split only, never on this full-dataset version.

---

## Part B — Predictive modeling

### Stratified split (Task 7)

Overall `survived` balance: 61.8% / 38.2% — a moderate imbalance. A plain random split can, by chance, skew that ratio further in either the train or test fold, making test metrics noisy and potentially starving training of minority (survived) examples. `stratify=y` keeps both splits at ~62%/38%, confirmed by the printed balances in `modeling_output.txt` (train 61.7/38.3, test 61.8/38.2).

### Preprocessing (Task 8)

A `ColumnTransformer` (median-impute + scale for numeric columns; most-frequent-impute + one-hot for `sex`/`embarked`) wrapped in a `Pipeline` with each classifier. Because `Pipeline.fit(X_train, y_train)` is the only place `.fit`/`.fit_transform` is called, and `.predict(X_test)` internally only calls `.transform`, the fit-on-train/transform-on-test separation is structural, not manual.

### Three classifiers (Task 9–10)

Decision tree visualized in `charts/decision_tree.png` (root split is `sex_female`, matching the bivariate finding that sex is the dominant predictor). ROC curves in `charts/roc_curves.png`.

| Model | Accuracy | Precision | Recall | F1 | AUC |
|---|---|---|---|---|---|
| Logistic Regression | 0.809 | 0.783 | 0.691 | 0.734 | **0.861** |
| Decision Tree | 0.764 | 0.760 | 0.559 | 0.644 | 0.837 |
| Random Forest | **0.809** | 0.766 | **0.721** | **0.742** | 0.820 |

### Imbalance handling comparison (Task 11)

Random Forest, three ways:

| Strategy | Precision | Recall | F1 |
|---|---|---|---|
| Baseline (no handling) | 0.766 | 0.721 | 0.742 |
| `class_weight='balanced'` | 0.766 | 0.721 | 0.742 |
| SMOTE (train fold only) | 0.761 | **0.750** | **0.756** |

**Conclusion**: SMOTE gave the best recall/F1 here, slightly outperforming both the untouched baseline and `class_weight='balanced'` (which had virtually no effect on this Random Forest — likely because 200 trees with bootstrap sampling already handle a moderate 62/38 imbalance reasonably well on their own). Since the imbalance is moderate rather than severe, the differences are small, but SMOTE's synthetic oversampling of the minority class gave the forest slightly more to learn from without touching the test set.

### Hyperparameter tuning (Task 12)

`GridSearchCV` over `n_estimators ∈ {100,200,300}`, `max_depth ∈ {None,5,10}`, `max_features ∈ {sqrt, log2}`, 5-fold CV:

- **Best params**: `max_depth=5, max_features='sqrt', n_estimators=300`
- **Best CV accuracy**: 0.820
- **OOB score** of the best estimator: **0.8214**

### Regression side-task — predicting fare (Task 13)

Linear regression predicting `fare` from `pclass, age, sibsp, parch, sex, embarked, survived`:

- MAE = **21.099**, RMSE = **41.702**, R² = **0.348**, Adjusted R² = **0.321**

Residual plot: `charts/regression_residuals.png`. The spread of residuals visibly **fans out** as predicted fare increases (tight near 0 for low predicted fares, much wider — including a residual over +400 — for high predicted fares). This is a clear case of **heteroscedasticity**: the model's error variance is not constant across the range of predictions, which is consistent with `fare`'s heavy right-skew (a linear model struggles equally to bound errors at both the cheap and very-expensive ends).

### Final comparison & recommendation (Task 14)

**Classification metrics** (own scale, 0-1 where higher is better):

| Model | Accuracy | Precision | Recall | F1 | AUC |
|---|---|---|---|---|---|
| Logistic Regression | 0.809 | 0.783 | 0.691 | 0.734 | 0.861 |
| Decision Tree | 0.764 | 0.760 | 0.559 | 0.644 | 0.837 |
| Random Forest | 0.809 | 0.766 | 0.721 | 0.742 | 0.820 |

**Regression metrics** (own scale, fare prediction, not directly comparable to the table above):

| MAE | RMSE | R² | Adjusted R² |
|---|---|---|---|
| 21.099 | 41.702 | 0.348 | 0.321 |

**Recommendation**: Deploy the **Random Forest** classifier. It ties Logistic Regression on accuracy (0.809) but has the best recall (0.721) and best F1 (0.742) of the three, meaning it catches more true survivors while keeping precision comparable (0.766 vs 0.783 for Logistic Regression). Logistic Regression edges it out on AUC (0.861 vs 0.820), so it ranks probabilities slightly better overall, but for a deployed model making concrete survived/died decisions, Random Forest's stronger recall/F1 balance and its resistance to the overfitting the single Decision Tree clearly shows (accuracy=0.764, well behind the other two) make it the safer production choice.

### Saved pipeline (Task 15)

`titanic_survival_pipeline.joblib` contains the complete fitted `Pipeline` (ColumnTransformer + RandomForestClassifier) trained on the training split. Reloading it with `joblib.load(...)` and calling `.predict()` on a raw, unpreprocessed one-row DataFrame (a hypothetical 1st-class, 29-year-old female, fare £100, embarked S) correctly returns `survived=1` with `P(survive)=1.000` — confirming the saved artifact preprocesses and predicts end-to-end without any manual pre-transform step.
