"""
01_eda.py
---------
Part A: load, profile, clean, and explore the Titanic dataset.
This is the ONE AND ONLY sns.load_dataset('titanic') call in the whole module.
Saves titanic.csv as the committed offline fallback immediately after loading,
BEFORE any cleaning, so 02_modeling.py can start from the same raw data too
if needed. All later steps (including 02_modeling.py) build on this.
"""
import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

pd.set_option("display.width", 120)
pd.set_option("display.max_columns", 20)

CHARTS_DIR = "charts"

# ---------------------------------------------------------------------------
# Task 1: Load + profile
# ---------------------------------------------------------------------------
print("="*70, "\nTASK 1: LOAD + PROFILE\n", "="*70)

df_raw = sns.load_dataset("titanic")

# Save the offline fallback immediately, before any cleaning.
df_raw.to_csv("titanic.csv", index=False)
print("Saved raw dataset to titanic.csv (offline fallback)\n")

print("df.shape:", df_raw.shape)
print("\ndf.info():")
df_raw.info()
print("\ndf.describe():")
print(df_raw.describe(include="all"))

print("\n--- Missing value % per column (only columns with any missing) ---")
missing_pct = (df_raw.isna().sum() / len(df_raw) * 100).round(2)
missing_pct = missing_pct[missing_pct > 0].sort_values(ascending=False)
print(missing_pct)

# ---------------------------------------------------------------------------
# Task 2: Missing-value handling (threshold rule)
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 2: MISSING-VALUE HANDLING\n", "="*70)

df = df_raw.copy()

# embarked / embark_town: 0.22% missing -> UNDER 5% -> drop those rows.
before = len(df)
df = df.dropna(subset=["embarked", "embark_town"])
print(f"embarked/embark_town: 0.22% missing (< 5%) -> dropped {before - len(df)} row(s).")

# age: 19.87% missing -> IN the 5%-30% band -> impute.
# Median chosen over mean because age is right-skewed (a few elderly
# passengers pull the mean up) -- median is robust to that skew.
age_median = df["age"].median()
df["age"] = df["age"].fillna(age_median)
print(f"age: 19.87% missing (5%-30%) -> imputed with median age = {age_median}")

# deck: 77.22% missing -> too high to impute reliably (we'd be inventing
# a deck for 4 out of 5 passengers). Decision: DROP the column.
# Justification: with over three-quarters of values missing, any imputed
# or "Missing"-category deck would carry almost no real information, and
# deck is not required by anything else in this module (survival analysis
# and the modeling pipeline both use class/pclass instead, which is
# complete and carries similar "where on the ship" signal).
df = df.drop(columns=["deck"])
print("deck: 77.22% missing (very high) -> DROPPED the column "
      "(imputing would be unreliable at this missing rate; "
      "pclass/class captures similar information and is fully populated).")

print("\nRemaining missing values after cleaning:")
print(df.isna().sum()[df.isna().sum() > 0])
print(f"\nShape after cleaning: {df.shape}")

# Re-save the cleaned CSV -- this is the DataFrame every later step uses.
df.to_csv("titanic.csv", index=False)
print("Re-saved cleaned dataset to titanic.csv (this is what 02_modeling.py reads)")

# ---------------------------------------------------------------------------
# Task 3: Univariate analysis -- age, fare
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 3: UNIVARIATE ANALYSIS\n", "="*70)

fig, axes = plt.subplots(2, 2, figsize=(12, 8))
sns.histplot(df["age"], kde=True, ax=axes[0, 0], color="steelblue")
axes[0, 0].set_title("Age distribution")
sns.boxplot(x=df["age"], ax=axes[0, 1], color="steelblue")
axes[0, 1].set_title("Age boxplot")
sns.histplot(df["fare"], kde=True, ax=axes[1, 0], color="darkorange")
axes[1, 0].set_title("Fare distribution")
sns.boxplot(x=df["fare"], ax=axes[1, 1], color="darkorange")
axes[1, 1].set_title("Fare boxplot")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/univariate_age_fare.png", dpi=110)
plt.close()
print(f"Saved {CHARTS_DIR}/univariate_age_fare.png")


def iqr_outliers(series, name):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    n_out = ((series < lower) | (series > upper)).sum()
    print(f"{name}: Q1={q1:.2f}, Q3={q3:.2f}, IQR={iqr:.2f}, "
          f"bounds=[{lower:.2f}, {upper:.2f}] -> {n_out} outliers")
    return n_out


age_outliers = iqr_outliers(df["age"], "age")
fare_outliers = iqr_outliers(df["fare"], "fare")

fare_mean = df["fare"].mean()
fare_median = df["fare"].median()
fare_mode = df["fare"].mode()[0]
print(f"\nfare: mean={fare_mean:.2f}, median={fare_median:.2f}, mode={fare_mode:.2f}")
if fare_mean > fare_median > fare_mode:
    skew_desc = "right-skewed (mean > median > mode: a long tail of high fares pulls the mean up)"
elif fare_mean < fare_median < fare_mode:
    skew_desc = "left-skewed (mean < median < mode)"
else:
    skew_desc = "roughly symmetric"
print(f"fare distribution: {skew_desc}")

# ---------------------------------------------------------------------------
# Task 4: Bivariate analysis
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 4: BIVARIATE ANALYSIS\n", "="*70)

# (a) survival rate by sex -- boolean masking
male_mask = df["sex"] == "male"
female_mask = df["sex"] == "female"
sr_male = df.loc[male_mask, "survived"].mean()
sr_female = df.loc[female_mask, "survived"].mean()
print(f"Survival rate by sex: male={sr_male:.3f}, female={sr_female:.3f}")

# (b) survival rate by pclass
for pc in sorted(df["pclass"].unique()):
    mask = df["pclass"] == pc
    print(f"Survival rate, pclass={pc}: {df.loc[mask, 'survived'].mean():.3f}")

# (c) survival rate by sex AND pclass (combined boolean masking with &)
print("\nSurvival rate by sex & pclass:")
for sex_val, sex_mask in [("male", male_mask), ("female", female_mask)]:
    for pc in sorted(df["pclass"].unique()):
        combined_mask = sex_mask & (df["pclass"] == pc)
        rate = df.loc[combined_mask, "survived"].mean()
        print(f"  sex={sex_val}, pclass={pc}: {rate:.3f}  (n={combined_mask.sum()})")

# Correlation matrix -- exactly these 6 numeric columns
corr_cols = ["survived", "pclass", "age", "sibsp", "parch", "fare"]
corr_matrix = df[corr_cols].corr()
print("\nCorrelation matrix:\n", corr_matrix.round(3))

plt.figure(figsize=(7, 6))
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", center=0, vmin=-1, vmax=1)
plt.title("Correlation matrix (6 numeric columns)")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/correlation_heatmap.png", dpi=110)
plt.close()
print(f"Saved {CHARTS_DIR}/correlation_heatmap.png")

# Find the two strongest off-diagonal correlations by |value|
corr_pairs = []
for i in range(len(corr_cols)):
    for j in range(i + 1, len(corr_cols)):
        c1, c2 = corr_cols[i], corr_cols[j]
        corr_pairs.append((c1, c2, corr_matrix.loc[c1, c2]))
corr_pairs.sort(key=lambda t: abs(t[2]), reverse=True)
print("\nTop 2 strongest correlations (by |r|):")
for c1, c2, r in corr_pairs[:2]:
    print(f"  {c1} <-> {c2}: r = {r:.3f}")

# ---------------------------------------------------------------------------
# Task 5: Multivariate "data story" -- 4+ charts
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 5: MULTIVARIATE DATA STORY\n", "="*70)

# Chart 1: survival rate by sex & pclass (bar)
plt.figure(figsize=(7, 5))
sns.barplot(data=df, x="pclass", y="survived", hue="sex")
plt.title("Survival rate by class and sex")
plt.ylabel("Survival rate")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/story_1_survival_by_class_sex.png", dpi=110)
plt.close()

# Chart 2: age distribution split by survival (box)
plt.figure(figsize=(7, 5))
sns.boxplot(data=df, x="survived", y="age")
plt.title("Age distribution by survival outcome")
plt.xlabel("Survived (0=No, 1=Yes)")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/story_2_age_by_survival.png", dpi=110)
plt.close()

# Chart 3: fare vs age scatter, colored by survival
plt.figure(figsize=(7, 5))
sns.scatterplot(data=df, x="age", y="fare", hue="survived", alpha=0.6)
plt.title("Fare vs age, colored by survival")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/story_3_fare_age_scatter.png", dpi=110)
plt.close()

# Chart 4: survival rate by family size (sibsp+parch) bar
df["family_size"] = df["sibsp"] + df["parch"]
plt.figure(figsize=(7, 5))
sns.barplot(data=df, x="family_size", y="survived", color="mediumseagreen")
plt.title("Survival rate by family size (sibsp + parch)")
plt.ylabel("Survival rate")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/story_4_survival_by_family_size.png", dpi=110)
plt.close()

# Chart 5 (bonus): pairplot of key numeric variables
pairgrid = sns.pairplot(
    df[["survived", "age", "fare", "pclass"]], hue="survived", diag_kind="hist"
)
pairgrid.savefig(f"{CHARTS_DIR}/story_5_pairplot.png", dpi=110)
plt.close("all")

print("Saved 5 story charts to charts/")
df.drop(columns=["family_size"], inplace=True)  # was just for the chart

# ---------------------------------------------------------------------------
# Task 6: Standardization sanity check (EDA-only; NOT used by modeling stage)
# ---------------------------------------------------------------------------
print("\n" + "="*70, "\nTASK 6: STANDARDIZATION SANITY CHECK (EDA ONLY)\n", "="*70)

print("Before standardization:")
print(df[["age", "fare"]].agg(["mean", "std"]).round(3))

df_scaled_check = df.copy()
for col in ["age", "fare"]:
    df_scaled_check[col + "_z"] = (df[col] - df[col].mean()) / df[col].std()

print("\nAfter z-score standardization (age_z, fare_z):")
print(df_scaled_check[["age_z", "fare_z"]].agg(["mean", "std"]).round(3))
print("\n(mean ~0, std ~1 confirms the transform worked as expected -- "
      "this is a sanity check only; the modeling pipeline in 02_modeling.py "
      "fits its own StandardScaler on the training split only.)")

print("\n" + "="*70)
print("01_eda.py complete. titanic.csv (cleaned) is saved for 02_modeling.py.")
print("="*70)
