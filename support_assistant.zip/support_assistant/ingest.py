"""
Ingestion: load the 8 corpus documents, chunk them, embed each chunk with
all-MiniLM-L6-v2 (sentence-transformers, local, no API key), and store the
embeddings in a persistent ChromaDB collection.

Chunking scheme: one chunk per document. Each document is already a single
short policy paragraph, so a per-document chunk is a faithful, minimal-loss
representation (no sentence gets split away from its surrounding context).

Run directly to (re)build the index:
    python ingest.py
"""

import os
import glob

import chromadb
from sentence_transformers import SentenceTransformer

DOCS_DIR = os.path.join(os.path.dirname(__file__), "docs")
CHROMA_DIR = os.path.join(os.path.dirname(__file__), "chroma_db")
COLLECTION_NAME = "zepto_policies"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"


def load_documents() -> list[dict]:
    """Load each docs/doc_XX.txt file as one chunk, tagged with its doc id."""
    paths = sorted(glob.glob(os.path.join(DOCS_DIR, "doc_*.txt")))
    documents = []
    for path in paths:
        doc_id = os.path.splitext(os.path.basename(path))[0]  # e.g. "doc_01"
        with open(path, "r", encoding="utf-8") as f:
            text = f.read().strip()
        documents.append({"id": doc_id, "text": text})
    return documents


def build_index(persist: bool = True) -> "chromadb.Collection":
    """Embed all chunks and (re)build the ChromaDB collection."""
    documents = load_documents()
    if not documents:
        raise RuntimeError(f"No documents found in {DOCS_DIR}")

    model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    embeddings = model.encode([d["text"] for d in documents]).tolist()

    if persist:
        client = chromadb.PersistentClient(path=CHROMA_DIR)
    else:
        client = chromadb.Client()

    # Drop and recreate so re-running ingest.py is idempotent.
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass

    collection = client.create_collection(
        name=COLLECTION_NAME, metadata={"hnsw:space": "cosine"}
    )

    collection.add(
        ids=[d["id"] for d in documents],
        documents=[d["text"] for d in documents],
        embeddings=embeddings,
        metadatas=[{"doc_id": d["id"]} for d in documents],
    )

    print(f"Indexed {len(documents)} chunks into ChromaDB collection '{COLLECTION_NAME}'.")
    return collection


if __name__ == "__main__":
    build_index()
