"""
Optional real-LLM client, only imported/used when MOCK_LLM=0.

Not required for grading: the graded baseline never imports this module,
since MOCK_LLM defaults to "1" (mock mode) and every call site in graph.py
that would import this module is skipped in that default state.

Uses Groq's OpenAI-compatible chat completions API (console.groq.com free
tier) by default. Any other LLM API with a genuinely free tier can be
substituted by changing BASE_URL / MODEL / the request shape below.
"""

import os
import urllib.request
import json

BASE_URL = os.environ.get("LLM_BASE_URL", "https://api.groq.com/openai/v1/chat/completions")
MODEL = os.environ.get("LLM_MODEL", "llama-3.1-8b-instant")
API_KEY = os.environ.get("GROQ_API_KEY", "")


def call_llm(system_prompt: str, user_prompt: str) -> str:
    if not API_KEY:
        raise RuntimeError(
            "MOCK_LLM=0 was set but GROQ_API_KEY (or your chosen provider's "
            "key) is not in the environment. Set MOCK_LLM=1/unset to use the "
            "required offline mock baseline, or export an API key to use "
            "this optional extension."
        )

    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.2,
    }
    req = urllib.request.Request(
        BASE_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {API_KEY}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"]
