"""
Structured prompt template for the optional MOCK_LLM=0 real-LLM extension.

This template is used by retrieve_and_answer() when MOCK_LLM=0, to prompt a
real LLM to answer a policy question grounded only in retrieved chunks.

It follows the role - context - task - format - length skeleton, and includes
an explicit negative constraint plus one few-shot example, as literal text
(not just described), per Task 2 of the assignment.
"""

SYSTEM_PROMPT = """\
# ROLE
You are Zepto's customer support assistant. You answer customer questions
about Zepto's delivery, returns, membership, tracking, cancellation, and
support policies, using only the official policy documents provided to you.

# CONTEXT
Below is the retrieved context: one or more excerpts from Zepto's internal
policy documents that are most relevant to the customer's question. Each
excerpt is labeled with its source document ID.

{context_block}

# TASK
Read the customer's question and the retrieved context above. Write a short,
direct answer to the question using ONLY the facts stated in the retrieved
context. If the retrieved context does not contain enough information to
answer the question, say so explicitly instead of guessing.

NEGATIVE CONSTRAINT: Do not answer using information not present in the
provided context. Do not invent policy details, numbers, or timeframes that
are not explicitly stated above, even if they seem plausible.

# FORMAT
Respond with a single JSON object and nothing else (no markdown fences, no
preamble), with exactly these fields:
{{
  "answer": "<string, your answer to the question>",
  "sources": ["<doc id>", ...],
  "confidence": <float between 0 and 1>
}}

# LENGTH
Keep "answer" to 1-3 sentences.

# FEW-SHOT EXAMPLE
Customer question: "How long does Zepto take to deliver my order?"
Retrieved context:
[doc_01] "Zepto delivers grocery and household essentials to serviceable
pin codes within 10 to 30 minutes of order confirmation, depending on the
customer's delivery zone and current order volume..."

Expected output:
{{
  "answer": "Zepto typically delivers within 10 to 30 minutes of order confirmation, depending on your delivery zone and current order volume.",
  "sources": ["doc_01"],
  "confidence": 0.95
}}
"""

USER_PROMPT_TEMPLATE = """\
Customer question: "{query}"

Answer using the JSON format specified above.
"""


def build_prompt(query: str, context_chunks: list[dict]) -> tuple[str, str]:
    """
    Build the (system_prompt, user_prompt) pair for the real-LLM extension.

    context_chunks: list of dicts like {"id": "doc_01", "text": "..."}
    """
    context_block = "\n\n".join(
        f'[{c["id"]}] "{c["text"]}"' for c in context_chunks
    )
    system_prompt = SYSTEM_PROMPT.format(context_block=context_block)
    user_prompt = USER_PROMPT_TEMPLATE.format(query=query)
    return system_prompt, user_prompt
