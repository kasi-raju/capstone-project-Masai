"""
Retrieval helper used by graph.py's retrieve_and_answer node.

Embeds the incoming query with the same local all-MiniLM-L6-v2 model used at
ingest time, and queries ChromaDB for the top-k most similar chunks by
cosine similarity. This step always runs for real, in both MOCK_LLM modes,
since embeddings + ChromaDB need no API key and no network call.
"""

import os
import threading

import chromadb
from sentence_transformers import SentenceTransformer

from ingest import CHROMA_DIR, COLLECTION_NAME, EMBEDDING_MODEL_NAME, build_index

_lock = threading.Lock()
_model = None
_collection = None


def _get_model() -> SentenceTransformer:
    global _model
    if _model is None:
        with _lock:
            if _model is None:
                _model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    return _model


def _get_collection():
    global _collection
    if _collection is None:
        with _lock:
            if _collection is None:
                client = chromadb.PersistentClient(path=CHROMA_DIR)
                try:
                    _collection = client.get_collection(COLLECTION_NAME)
                except Exception:
                    # Index hasn't been built yet on this machine -> build it now.
                    _collection = build_index(persist=True)
    return _collection


def retrieve_top_k(query: str, k: int = 3) -> list[dict]:
    """
    Embed `query` and return the top-k most similar chunks.

    Returns a list of dicts: {"id": doc_id, "text": chunk_text, "distance": float}
    ordered from most to least similar.
    """
    model = _get_model()
    collection = _get_collection()

    query_embedding = model.encode([query]).tolist()
    results = collection.query(query_embeddings=query_embedding, n_results=k)

    chunks = []
    ids = results.get("ids", [[]])[0]
    docs = results.get("documents", [[]])[0]
    distances = results.get("distances", [[]])[0]
    for chunk_id, text, dist in zip(ids, docs, distances):
        chunks.append({"id": chunk_id, "text": text, "distance": dist})
    return chunks
