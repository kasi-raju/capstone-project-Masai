"""
FastAPI wrapper for the Zepto support assistant LangGraph pipeline.

Run locally:
    uvicorn main:app --host 0.0.0.0 --port 7860

MOCK_LLM defaults to "1" (fully offline, deterministic mock mode) -- this is
what gets graded. Set MOCK_LLM=0 (and an API key, see llm_client.py) only if
you want to try the optional, ungraded real-LLM extension.
"""

from fastapi import FastAPI

from models import AskRequest, AskResponse
from graph import run_query

app = FastAPI(
    title="Zepto Support Assistant",
    description="LangGraph-orchestrated RAG service over Zepto's policy corpus.",
    version="1.0.0",
)


@app.get("/")
def health():
    return {"status": "ok", "service": "zepto-support-assistant"}


@app.post("/ask", response_model=AskResponse)
def ask(request: AskRequest) -> AskResponse:
    return run_query(request.query)
