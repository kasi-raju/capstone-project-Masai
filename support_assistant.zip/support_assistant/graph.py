"""
LangGraph orchestration for the Zepto support assistant.

Graph shape:

              +------------------+
              |  classify_intent  |
              +------------------+
                /              \\
   policy_question           general_question
              /                    \\
+----------------------+   +----------------+
| retrieve_and_answer  |   | direct_answer  |
+----------------------+   +----------------+
              \\                    /
               \\                  /
                +----------------+
                |      END        |
                +----------------+

Every node's *generation* step branches on the MOCK_LLM environment
variable:
  - MOCK_LLM unset, or "1" (default, graded baseline): deterministic,
    rule-based / templated logic. No LLM call, no network call.
  - MOCK_LLM="0" (optional, ungraded extension): calls a real LLM.

The routing logic itself (the conditional edge out of classify_intent) does
NOT depend on MOCK_LLM -- only the generation step inside each node does.
"""

from __future__ import annotations

import json
import os
from typing import TypedDict

from langgraph.graph import StateGraph, END

from models import AskResponse
from prompt_template import build_prompt
from retrieval import retrieve_top_k

KEYWORDS = [
    "delivery",
    "return",
    "refund",
    "membership",
    "tracking",
    "cancel",
    "gift card",
    "support hours",
]

DIRECT_ANSWER_FALLBACK = "I can only answer questions about Zepto policies right now."

TOP_CHUNK_SNIPPET_LEN = 200


def _mock_llm_enabled() -> bool:
    """True when running the required, graded, fully offline mock baseline."""
    return os.environ.get("MOCK_LLM", "1") != "0"


class GraphState(TypedDict, total=False):
    query: str
    intent: str  # "policy_question" | "general_question"
    retrieved_chunks: list[dict]
    answer: str
    sources: list[str]
    confidence: float


# ---------------------------------------------------------------------------
# Node 1: classify_intent
# ---------------------------------------------------------------------------
def classify_intent(state: GraphState) -> GraphState:
    query = state["query"]

    if _mock_llm_enabled():
        # Mock mode (graded baseline): keyword heuristic, no LLM call.
        lowered = query.lower()
        intent = "policy_question" if any(kw in lowered for kw in KEYWORDS) else "general_question"
    else:
        # Optional MOCK_LLM=0 extension: call the LLM to classify instead.
        intent = _llm_classify_intent(query)

    return {**state, "intent": intent}


def _llm_classify_intent(query: str) -> str:
    """Optional real-LLM classification path (MOCK_LLM=0)."""
    from llm_client import call_llm  # local import: only needed in the optional path

    system_prompt = (
        "Classify the user's question as exactly one word: 'policy_question' "
        "if it concerns Zepto's delivery, returns, refunds, membership, "
        "order tracking, cancellation, gift cards, or support hours, "
        "otherwise 'general_question'. Reply with only that one word."
    )
    raw = call_llm(system_prompt, query).strip().lower()
    return "policy_question" if "policy_question" in raw else "general_question"


# ---------------------------------------------------------------------------
# Node 2: retrieve_and_answer  (policy_question path)
# ---------------------------------------------------------------------------
def retrieve_and_answer(state: GraphState) -> GraphState:
    query = state["query"]

    # Retrieval always runs for real, in both MOCK_LLM modes: embeddings +
    # ChromaDB need no API key and no network call.
    chunks = retrieve_top_k(query, k=3)
    sources = [c["id"] for c in chunks]

    if _mock_llm_enabled():
        # Mock mode (graded baseline): canned templated answer, no LLM call.
        top_chunk_snippet = chunks[0]["text"][:TOP_CHUNK_SNIPPET_LEN] if chunks else ""
        answer = f"Based on the retrieved context: {top_chunk_snippet}"
        confidence = 1.0
    else:
        # Optional MOCK_LLM=0 extension: prompt the real LLM, grounded only
        # in the retrieved chunks, with schema validation + retry.
        answer, sources, confidence = _llm_answer_with_context(query, chunks, sources)

    return {
        **state,
        "retrieved_chunks": chunks,
        "answer": answer,
        "sources": sources,
        "confidence": confidence,
    }


def _llm_answer_with_context(query: str, chunks: list[dict], sources: list[str]):
    """Optional real-LLM grounded-answer path (MOCK_LLM=0), with schema
    validation and up to 2 corrective retries."""
    from llm_client import call_llm  # local import: only needed in the optional path

    system_prompt, user_prompt = build_prompt(query, chunks)

    last_error = None
    for attempt in range(3):  # 1 initial try + 2 corrective retries
        prompt = system_prompt if attempt == 0 else (
            system_prompt
            + f"\n\nYour previous response was invalid JSON or failed schema "
              f"validation ({last_error}). Reply again with ONLY a valid JSON "
              f"object matching the schema."
        )
        raw = call_llm(prompt, user_prompt)
        try:
            parsed = json.loads(raw)
            validated = AskResponse(
                answer=parsed["answer"],
                sources=parsed.get("sources", sources),
                confidence=float(parsed.get("confidence", 0.5)),
            )
            return validated.answer, validated.sources, validated.confidence
        except Exception as e:  # noqa: BLE001 - broad on purpose, feeds retry loop
            last_error = str(e)
            continue

    # All attempts failed validation: clearly marked error response.
    return (
        f"[ERROR] LLM output failed schema validation after 3 attempts: {last_error}",
        sources,
        0.0,
    )


# ---------------------------------------------------------------------------
# Node 3: direct_answer  (general_question path)
# ---------------------------------------------------------------------------
def direct_answer(state: GraphState) -> GraphState:
    query = state["query"]

    if _mock_llm_enabled():
        # Mock mode (graded baseline): fixed canned string, no LLM call.
        answer = DIRECT_ANSWER_FALLBACK
        confidence = 1.0
    else:
        # Optional MOCK_LLM=0 extension: prompt the LLM directly, no retrieval.
        from llm_client import call_llm

        answer = call_llm(
            "You are Zepto's customer support assistant. Answer briefly and "
            "helpfully. This question is unrelated to Zepto policy, so answer "
            "from general knowledge.",
            query,
        )
        confidence = 0.7

    return {**state, "answer": answer, "sources": [], "confidence": confidence}


# ---------------------------------------------------------------------------
# Conditional routing (does not depend on MOCK_LLM)
# ---------------------------------------------------------------------------
def route_from_classify(state: GraphState) -> str:
    return "retrieve_and_answer" if state["intent"] == "policy_question" else "direct_answer"


# ---------------------------------------------------------------------------
# Build the graph
# ---------------------------------------------------------------------------
def build_graph():
    workflow = StateGraph(GraphState)

    workflow.add_node("classify_intent", classify_intent)
    workflow.add_node("retrieve_and_answer", retrieve_and_answer)
    workflow.add_node("direct_answer", direct_answer)

    workflow.set_entry_point("classify_intent")

    workflow.add_conditional_edges(
        "classify_intent",
        route_from_classify,
        {
            "retrieve_and_answer": "retrieve_and_answer",
            "direct_answer": "direct_answer",
        },
    )

    workflow.add_edge("retrieve_and_answer", END)
    workflow.add_edge("direct_answer", END)

    return workflow.compile()


_compiled_graph = None


def get_graph():
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_graph()
    return _compiled_graph


def run_query(query: str) -> AskResponse:
    """Run the full graph for a single query and return the validated schema."""
    graph = get_graph()
    final_state = graph.invoke({"query": query})
    return AskResponse(
        answer=final_state["answer"],
        sources=final_state.get("sources", []),
        confidence=final_state["confidence"],
    )
