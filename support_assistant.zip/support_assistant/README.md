# Zepto Support Assistant (`/support_assistant`)

A small RAG service over Zepto's own policy corpus, orchestrated with
LangGraph and served via FastAPI. Graded end-to-end with `MOCK_LLM` left at
its default (`1` / unset) — a fully offline, deterministic mode that needs
no signup, no API key, and no network call to any LLM provider.

## 1. Setup

```bash
cd support_assistant
python -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt

# Build the ChromaDB index from docs/*.txt (also runs automatically on
# first query if you skip this, but it's faster to do it once up front):
python ingest.py
```

## 2. Run the API (graded configuration — MOCK_LLM left at default)

```bash
uvicorn main:app --host 0.0.0.0 --port 7860
```

## 3. Example calls

Run these two `curl` commands against the running server and paste the raw
JSON responses below. One is designed to trigger retrieval (contains a
policy keyword), one is designed not to (no policy keyword).

**Call 1 — should route to `retrieve_and_answer` (contains "delivery"):**
```bash
curl -s -X POST http://localhost:7860/ask \
  -H "Content-Type: application/json" \
  -d '{"query": "How much does delivery cost on a small order?"}' | python -m json.tool
```
Raw JSON response:
```json
<PASTE THE ACTUAL RESPONSE HERE AFTER RUNNING LOCALLY>
```

**Call 2 — should route to `direct_answer` (no policy keyword):**
```bash
curl -s -X POST http://localhost:7860/ask \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the capital of France?"}' | python -m json.tool
```
Raw JSON response:
```json
<PASTE THE ACTUAL RESPONSE HERE AFTER RUNNING LOCALLY>
```

> Tip: to also demonstrate the other named keywords, you can additionally
> try queries like `"Can I get a refund for a spoiled item?"`, `"What's
> Zepto's membership pricing?"`, `"I need tracking on my order"`, `"How do I
> cancel my order?"`, `"Do you sell gift cards?"`, and `"What are your
> support hours?"` — each contains one of the exact keywords the classifier
> checks for (`delivery`, `return`, `refund`, `membership`, `tracking`,
> `cancel`, `gift card`, `support hours`).

## 4. Docker (required, graded baseline — local build & run only)

```bash
docker build -t zepto-support-assistant .
docker run -p 7860:7860 zepto-support-assistant
# then curl http://localhost:7860/ask as above
```

No push to a registry or cloud deploy is required for full marks on this
step.

## 5. Optional, ungraded extensions (not required for grading)

- **Real LLM (MOCK_LLM=0):** set `MOCK_LLM=0` and `GROQ_API_KEY=<your key>`
  (free tier at console.groq.com, no card required) before starting
  uvicorn. This routes `classify_intent`, `retrieve_and_answer`, and
  `direct_answer` through `llm_client.py` instead of the canned logic, and
  the structured prompt in `prompt_template.py` is used to ground the
  answer. If you try this, note here which provider/free tier you used.
- **Hugging Face Spaces deploy:** if attempted, put the live Space URL and
  the tier used (free CPU) here.

*(Neither extension was required or used to satisfy the graded baseline
above; leave this section as-is, or fill it in if you attempt them.)*

---

## Architecture: the RAG pipeline, stage by stage

**Ingestion.** The 8 policy documents live as plain text files in
`docs/doc_01.txt` … `docs/doc_08.txt`, one Zepto policy per file (delivery,
returns, membership, tracking, cancellation, damaged/missing items, gift
cards, support hours). `ingest.py:load_documents()` reads each file and
treats the whole file as a single chunk — each document is already one
short, self-contained policy paragraph, so per-document chunking avoids
splitting a policy statement away from its own context.

**Embedding.** `ingest.py:build_index()` loads the local
`sentence-transformers` model `all-MiniLM-L6-v2` and calls
`model.encode(...)` on the 8 chunk texts to get their vector embeddings —
entirely on-machine, no API key, no network call. Those vectors, plus the
raw chunk text and a `doc_id` metadata tag, are written into a persistent
ChromaDB collection named `zepto_policies` (stored under
`support_assistant/chroma_db/`, configured for cosine similarity via
`hnsw:space: cosine`).

**Retrieval.** `retrieval.py:retrieve_top_k()` embeds the incoming user
query with the *same* `all-MiniLM-L6-v2` model, then calls
`collection.query(...)` on the `zepto_policies` ChromaDB collection to fetch
the top-3 chunks by cosine similarity. This is invoked from the
`retrieve_and_answer` LangGraph node, and — per the assignment — this
retrieval step always executes for real in both `MOCK_LLM` states, since it
needs no external API.

**Generation.** `graph.py` builds a `langgraph.graph.StateGraph` over a
`GraphState` `TypedDict` with three nodes:
1. `classify_intent` — routes the query to `policy_question` or
   `general_question`.
2. `retrieve_and_answer` — for `policy_question`, calls retrieval above,
   then generates the answer.
3. `direct_answer` — for `general_question`, generates directly with no
   retrieval.

A conditional edge (`route_from_classify`) leaves `classify_intent` and
sends the state to either `retrieve_and_answer` or `direct_answer`; this
routing decision is independent of `MOCK_LLM`. The *generation* step inside
each of the three nodes is what branches on `MOCK_LLM`:

| Node | MOCK_LLM=1 / unset (default, graded) | MOCK_LLM=0 (optional extension) |
|---|---|---|
| `classify_intent` | Keyword heuristic over 8 fixed terms, no LLM call | Calls the LLM to classify |
| `retrieve_and_answer` | Retrieval runs for real either way; answer is the canned `f"Based on the retrieved context: {top_chunk_snippet}"` template, no LLM call | Retrieval runs for real; answer is generated by the LLM using `prompt_template.py`'s role/context/task/format/length prompt, grounded only in the retrieved chunks, with JSON-schema validation and up to 2 corrective retries on failure |
| `direct_answer` | Fixed canned string, no LLM call | LLM answers directly from general knowledge, no retrieval |

**Structured output.** Regardless of path, `graph.py:run_query()` returns a
validated `models.AskResponse` (Pydantic: `answer: str`, `sources:
list[str]`, `confidence: float` in `[0, 1]`). In mock mode this is populated
deterministically in code — `sources` is the list of retrieved `doc_id`s for
`policy_question`, empty for `general_question`; `confidence` is fixed at
`1.0` — so there is no LLM output that could fail validation. In the
optional `MOCK_LLM=0` path, the raw LLM output is parsed as JSON and
validated against this same schema in `graph.py:_llm_answer_with_context()`;
on failure it retries up to 2 more times with a corrective instruction
appended to the prompt, and if all 3 attempts fail it returns a response
with `answer` prefixed `"[ERROR] ..."` and `confidence: 0.0` rather than
raising.

**Serving.** `main.py` wraps `graph.run_query()` in a FastAPI app with
`POST /ask`, accepting `models.AskRequest` (`{"query": str}`) and returning
`models.AskResponse`. `Dockerfile` builds this into a container that runs
`ingest.py` at build time (warming the ChromaDB index) and serves the app
via `uvicorn main:app --host 0.0.0.0 --port 7860` on `docker run`.

**Data flow, end to end:**
```
docs/*.txt --(ingest.py: load + chunk)--> raw chunks
          --(ingest.py: SentenceTransformer.encode)--> embeddings
          --(ingest.py: collection.add)--> ChromaDB "zepto_policies"

client --> POST /ask {"query": ...} --> main.py --> graph.run_query()
        --> classify_intent (keyword heuristic, MOCK_LLM branch)
        --> [conditional edge]
              -> retrieve_and_answer: retrieval.py queries ChromaDB (always real)
                                       --> canned template OR LLM (MOCK_LLM branch)
              -> direct_answer: canned string OR LLM (MOCK_LLM branch)
        --> AskResponse{answer, sources, confidence} --> client
```
