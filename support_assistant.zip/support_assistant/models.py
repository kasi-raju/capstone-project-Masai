"""
Pydantic schemas for the /support_assistant service.

- AskRequest: the incoming request body for POST /ask
- AskResponse: the enforced JSON output schema for the final answer
"""

from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    query: str = Field(..., min_length=1, description="The user's natural-language question.")


class AskResponse(BaseModel):
    answer: str = Field(..., description="The generated answer text.")
    sources: list[str] = Field(
        default_factory=list,
        description="Chunk/document IDs used to ground the answer. Empty for general_question answers.",
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Confidence score for the answer, between 0 and 1."
    )
